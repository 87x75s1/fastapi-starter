const { http } = require('../../utils/request')
const auth = require('../../utils/auth')

Page({
  data: {
    isAdmin: false,
    activeTab: 'stats',
    stats: {},
    // 商品表单
    productForm: { name: '', description: '', price: '', image: '', category: '', stock: '' },
    products: [],
    // 订单
    orders: [],
    orderStatusMap: { 0: '待付款', 1: '已付款', 2: '已完成', 3: '已取消' },
    // 反馈
    feedbacks: [],
    replyContent: '',
    // 配置
    configs: [],
    configForm: { key: '', value: '', description: '' },
    // 用户
    users: [],
  },

  onShow() {
    const userInfo = auth.getUserInfo()
    if (!userInfo || userInfo.role !== 1) {
      wx.showToast({ title: '需要管理员权限', icon: 'none' })
      setTimeout(() => wx.switchTab({ url: '/pages/index/index' }), 1000)
      return
    }
    this.setData({ isAdmin: true })
    this.loadStats()
  },

  switchTab(e) {
    const tab = e.currentTarget.dataset.tab
    this.setData({ activeTab: tab })
    if (tab === 'stats') this.loadStats()
    else if (tab === 'product') this.loadProducts()
    else if (tab === 'order') this.loadOrders()
    else if (tab === 'feedback') this.loadFeedbacks()
    else if (tab === 'config') this.loadConfigs()
    else if (tab === 'user') this.loadUsers()
  },

  // ========== 统计 ==========
  async loadStats() {
    try {
      const data = await http.get('/api/admin/stats', {}, { auth: true, loading: false })
      this.setData({ stats: data })
    } catch (err) {}
  },

  // ========== 商品管理 ==========
  async loadProducts() {
    try {
      const data = await http.get('/api/product/list', { page_size: 100 }, { auth: true, loading: false })
      const items = data.items.map(item => { item.price_text = (item.price / 100).toFixed(2); return item })
      this.setData({ products: items })
    } catch (err) {}
  },

  onProductInput(e) {
    const field = e.currentTarget.dataset.field
    this.setData({ [`productForm.${field}`]: e.detail.value })
  },

  async onCreateProduct() {
    const form = this.data.productForm
    if (!form.name || !form.price) {
      wx.showToast({ title: '名称和价格必填', icon: 'none' }); return
    }
    try {
      await http.post('/api/admin/product/create', {
        name: form.name, description: form.description,
        price: Math.round(parseFloat(form.price) * 100),
        image: form.image, category: form.category,
        stock: parseInt(form.stock) || 0
      }, { auth: true })
      wx.showToast({ title: '创建成功', icon: 'success' })
      this.setData({ productForm: { name: '', description: '', price: '', image: '', category: '', stock: '' } })
      this.loadProducts()
    } catch (err) {}
  },

  async onDeleteProduct(e) {
    const id = e.currentTarget.dataset.id
    wx.showModal({
      title: '确认删除', content: '确定删除该商品吗？',
      success: async (res) => {
        if (res.confirm) {
          try {
            await http.delete(`/api/admin/product/${id}`, {}, { auth: true })
            wx.showToast({ title: '已删除', icon: 'success' })
            this.loadProducts()
          } catch (err) {}
        }
      }
    })
  },

  // ========== 订单管理 ==========
  async loadOrders() {
    try {
      const data = await http.get('/api/admin/order/list', { page_size: 50 }, { auth: true, loading: false })
      const items = data.items.map(order => {
        order.total_amount_text = (order.total_amount / 100).toFixed(2)
        if (order.items) order.items = order.items.map(oi => { oi.price_text = (oi.price / 100).toFixed(2); return oi })
        return order
      })
      this.setData({ orders: items })
    } catch (err) {}
  },

  async onUpdateOrderStatus(e) {
    const { id, status } = e.currentTarget.dataset
    const statusNames = { 1: '已付款', 2: '已完成', 3: '已取消' }
    wx.showModal({
      title: '确认操作', content: `确定将订单标记为"${statusNames[status]}"吗？`,
      success: async (res) => {
        if (res.confirm) {
          try {
            await http.put(`/api/admin/order/${id}/status`, { status }, { auth: true })
            wx.showToast({ title: '操作成功', icon: 'success' })
            this.loadOrders()
          } catch (err) {}
        }
      }
    })
  },

  // ========== 反馈管理 ==========
  async loadFeedbacks() {
    try {
      const data = await http.get('/api/admin/feedback/list', { page_size: 50 }, { auth: true, loading: false })
      this.setData({ feedbacks: data.items })
    } catch (err) {}
  },

  onReplyInput(e) { this.setData({ replyContent: e.detail.value }) },

  async onReplyFeedback(e) {
    const id = e.currentTarget.dataset.id
    const reply = this.data.replyContent
    if (!reply) { wx.showToast({ title: '请输入回复内容', icon: 'none' }); return }
    try {
      await http.put(`/api/admin/feedback/${id}/reply`, { reply }, { auth: true })
      wx.showToast({ title: '回复成功', icon: 'success' })
      this.setData({ replyContent: '' })
      this.loadFeedbacks()
    } catch (err) {}
  },

  // ========== 配置管理 ==========
  async loadConfigs() {
    try {
      const data = await http.get('/api/config/list', { page_size: 100 }, { auth: true, loading: false })
      this.setData({ configs: data.items })
    } catch (err) {}
  },

  onConfigInput(e) {
    const field = e.currentTarget.dataset.field
    this.setData({ [`configForm.${field}`]: e.detail.value })
  },

  async onCreateConfig() {
    const form = this.data.configForm
    if (!form.key) { wx.showToast({ title: '配置键必填', icon: 'none' }); return }
    try {
      await http.post('/api/admin/config/create', form, { auth: true })
      wx.showToast({ title: '创建成功', icon: 'success' })
      this.setData({ configForm: { key: '', value: '', description: '' } })
      this.loadConfigs()
    } catch (err) {}
  },

  async onDeleteConfig(e) {
    const id = e.currentTarget.dataset.id
    wx.showModal({
      title: '确认删除', content: '确定删除该配置吗？',
      success: async (res) => {
        if (res.confirm) {
          try {
            await http.delete(`/api/admin/config/${id}`, {}, { auth: true })
            wx.showToast({ title: '已删除', icon: 'success' })
            this.loadConfigs()
          } catch (err) {}
        }
      }
    })
  },

  // ========== 用户管理 ==========
  async loadUsers() {
    try {
      const data = await http.get('/api/admin/user/list', { page_size: 50 }, { auth: true, loading: false })
      this.setData({ users: data.items })
    } catch (err) {}
  },

  async onToggleRole(e) {
    const { id, role } = e.currentTarget.dataset
    const newRole = role === 1 ? 0 : 1
    const msg = newRole === 1 ? '设为管理员' : '取消管理员'
    wx.showModal({
      title: '确认操作', content: `确定${msg}吗？`,
      success: async (res) => {
        if (res.confirm) {
          try {
            await http.put(`/api/admin/user/${id}/role`, { role: newRole }, { auth: true })
            wx.showToast({ title: '操作成功', icon: 'success' })
            this.loadUsers()
          } catch (err) {}
        }
      }
    })
  }
})